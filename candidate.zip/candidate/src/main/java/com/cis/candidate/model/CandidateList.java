package com.cis.candidate.model;

import java.util.List;


public class CandidateList {

	private List<CandidateBasicModel> listOfCandidates;

	public List<CandidateBasicModel> getListOfCandidates() {
		return listOfCandidates;
	}

	public void setListOfCandidates(List<CandidateBasicModel> listOfCandidates) {
		this.listOfCandidates = listOfCandidates;
	}
	
	
	
}
