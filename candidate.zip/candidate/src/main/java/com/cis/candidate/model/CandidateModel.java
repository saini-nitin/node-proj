package com.cis.candidate.model;

public class CandidateModel {

    private String candidateId;
	private String candidateName;
	private String practice;
	private String customerAC;
	private String quarter;
	private String recievedDate;
	private String notes;
	private String offerPU;
	private String demandId;
	private String location;
	private String doj;
	
	private String candidateContact;
	private String status;
	private String remark;
	private String background;
	private String weekEndingDate;
	private String recievedMonth;
	private String parentSkillSet;
	private String responsible;
	private String profileAge;
	private String firstPanelistEmailId;
	private String secondPanelistEmailId;
	
	private String interviewId;
	
	private String responseStatus;
	private String candidateEmail;

	

	public String getCandidateEmail() {
		return candidateEmail;
	}

	public void setCandidateEmail(String candidateEmail) {
		this.candidateEmail = candidateEmail;
	}

	public String getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public String getPractice() {
		return practice;
	}

	public void setPractice(String practice) {
		this.practice = practice;
	}

	public String getCustomerAC() {
		return customerAC;
	}

	public void setCustomerAC(String customerAC) {
		this.customerAC = customerAC;
	}

	public String getQuarter() {
		return quarter;
	}

	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}

	public String getRecievedDate() {
		return recievedDate;
	}

	public void setRecievedDate(String recievedDate) {
		this.recievedDate = recievedDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getOfferPU() {
		return offerPU;
	}

	public void setOfferPU(String offerPU) {
		this.offerPU = offerPU;
	}

	public String getDemandId() {
		return demandId;
	}

	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getCandidateContact() {
		return candidateContact;
	}

	public void setCandidateContact(String candidateContact) {
		this.candidateContact = candidateContact;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public String getWeekEndingDate() {
		return weekEndingDate;
	}

	public void setWeekEndingDate(String weekEndingDate) {
		this.weekEndingDate = weekEndingDate;
	}

	public String getRecievedMonth() {
		return recievedMonth;
	}

	public void setRecievedMonth(String recievedMonth) {
		this.recievedMonth = recievedMonth;
	}

	public String getParentSkillSet() {
		return parentSkillSet;
	}

	public void setParentSkillSet(String parentSkillSet) {
		this.parentSkillSet = parentSkillSet;
	}

	public String getResponsible() {
		return responsible;
	}

	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}

	public String getProfileAge() {
		return profileAge;
	}

	public void setProfileAge(String profileAge) {
		this.profileAge = profileAge;
	}

	public String getInterviewId() {
		return interviewId;
	}

	public void setInterviewId(String interviewId) {
		this.interviewId = interviewId;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getFirstPanelistEmailId() {
		return firstPanelistEmailId;
	}

	public void setFirstPanelistEmailId(String firstPanelistEmailId) {
		this.firstPanelistEmailId = firstPanelistEmailId;
	}

	public String getSecondPanelistEmailId() {
		return secondPanelistEmailId;
	}

	public void setSecondPanelistEmailId(String secondPanelistEmailId) {
		this.secondPanelistEmailId = secondPanelistEmailId;
	}
	
}
