package com.cis.candidate.entity;

import com.cis.candidate.model.CandidateModel;

public class InterviewEntity {

	private String interviewId;
	private String firstPanelistEmailId;
	private String secondPanelistEmailId;
	private String scheduledDate;
	private String time;
	private String location;
	private String mode;
	
	private String startTime;
	private String endTime;
	private String candidateEmail;
	
	
	private CandidateModel candidateModel;
	
	public CandidateModel getCandidateModel() {
		return candidateModel;
	}
	public void setCandidateModel(CandidateModel candidateModel) {
		this.candidateModel = candidateModel;
	}
	public String getCandidateEmail() {
		return candidateEmail;
	}
	public void setCandidateEmail(String candidateEmail) {
		this.candidateEmail = candidateEmail;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getInterviewId() {
		return interviewId;
	}
	public void setInterviewId(String interviewId) {
		this.interviewId = interviewId;
	}
	public String getFirstPanelistEmailId() {
		return firstPanelistEmailId;
	}
	public void setFirstPanelistEmailId(String firstPanelistEmailId) {
		this.firstPanelistEmailId = firstPanelistEmailId;
	}
	public String getSecondPanelistEmailId() {
		return secondPanelistEmailId;
	}
	public void setSecondPanelistEmailId(String secondPanelistEmailId) {
		this.secondPanelistEmailId = secondPanelistEmailId;
	}
	public String getScheduledDate() {
		return scheduledDate;
	}
	public void setScheduledDate(String scheduledDate) {
		this.scheduledDate = scheduledDate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
}
