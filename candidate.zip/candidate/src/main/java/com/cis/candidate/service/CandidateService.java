package com.cis.candidate.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.cis.candidate.entity.CandidateEntity;
import com.cis.candidate.entity.InterviewEntity;
import com.cis.candidate.mapper.Mapper;
import com.cis.candidate.model.CandidateModel;
import com.cis.candidate.model.CandidateBasicModel;
import com.cis.candidate.model.CandidateInterviewModel;
import com.cis.candidate.repository.CandidateRepository;



@Service
public class CandidateService {
	
	@Autowired
	CandidateRepository candidateRepository;

	private static final Logger LOG = LoggerFactory.getLogger(CandidateService.class);
	
	
	public CandidateModel createCandidate(CandidateModel candidateModel) {
		Mapper mapper = new Mapper();
		RestTemplate restTemplate = new RestTemplate();
//		//String transactionUrl = "http://localhost:8300/cis/constants/search-location/";
//		String transactionUrl = "http://localhost:8302/cis/interview/create-interview";
////		if(candidateModel!=null) {
////			transactionUrl = transactionUrl + candidateModel.getLocationId();
////		}
//		UriComponentsBuilder builder = UriComponentsBuilder
//			    .fromUriString(transactionUrl);
//		String url = builder.toUriString();
//		LOG.info("URL   createCandidate   ::::: :::::::"+url);
//		LocationModel locationModel = restTemplate.getForObject(url,LocationModel.class);
//		LOG.info("interviewStatus   createCandidate   ::::: :::::::"+locationModel.getLocationId());
//		InterviewModel request = new InterviewModel();
//		request.setId((long) 341412);
//		request.setInterviewStatus("check");
//		
//		ResponseEntity<InterviewModel> interviewModel = restTemplate.postForEntity(url, request, InterviewModel.class);
//		
//		
		
		
		
		CandidateEntity candidateEntity = new CandidateEntity();
		candidateEntity = mapper.mapModelToEntity(candidateModel, candidateEntity);
	
		
		CandidateEntity candidateOutput = new CandidateEntity();
		candidateOutput = candidateRepository.insert(candidateEntity);
		CandidateModel candidateModelOutput = new CandidateModel();
		if(candidateOutput!=null) {
			candidateModelOutput = mapper.mapEntityToModel(candidateOutput, candidateModelOutput);
			if(candidateModelOutput!=null && candidateModelOutput.getCandidateId()!=null) {
				return candidateModelOutput;
			}else {
				candidateModelOutput.setResponseStatus("Create Candidate Operation failed. Please try after sometime");
			}
		}
		return candidateModelOutput;
	}
	
	public CandidateModel getCandidateDetails(String candidateId) {
		Mapper mapper = new Mapper();
		CandidateModel candidateModel = new CandidateModel();
		Optional<CandidateEntity> optionalEntity =  candidateRepository.findById(candidateId);
		if(optionalEntity.isPresent()) {
			candidateModel = mapper.mapEntityToModel(optionalEntity.get(), candidateModel);
		}else {
			candidateModel.setResponseStatus("Candidate Id not found");
		}
		return candidateModel;
	}
	
	
	public CandidateEntity updateCandidateDetail(CandidateModel candidateModel) {
		Mapper mapper = new Mapper();
		CandidateEntity candidateEntity = new CandidateEntity();
		candidateEntity = mapper.mapModelToEntity(candidateModel, candidateEntity);
		return candidateRepository.save(candidateEntity);
//		Mapper mapper = new Mapper();
//		CandidateEntity candidateEntity = new CandidateEntity();
//		//CandidateModel candidateModelOutpurResponse = new CandidateModel();
//		candidateEntity = mapper.mapModelToEntity(candidateModel, candidateEntity);
//		return mapper.mapEntityToModel(candidateRepository.save(candidateEntity), new CandidateModel());
	}
	
	public List<CandidateBasicModel> getAllCandidates() {
		List<CandidateBasicModel> candidateModelList = new ArrayList<>();
		List<CandidateEntity> candidateEntities = new ArrayList<>();
		Mapper mapper = new Mapper();
		candidateEntities =  candidateRepository.findAll();
		if(!candidateEntities.isEmpty()) {
			for(CandidateEntity candidateEntity: candidateEntities) {
				CandidateBasicModel candidateModel = new CandidateBasicModel();
				candidateModelList.add(mapper.mapEntityToModelBasic(candidateEntity,candidateModel));
			}
		}
		return candidateModelList;
	}
	
	public CandidateModel createCandidateInterview(CandidateInterviewModel candidateInterviewModel ) {
		String transactionUrl = "http://localhost:8302/cis/interview/create-interview";
		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder builder = UriComponentsBuilder
			    .fromUriString(transactionUrl);
		String url = builder.toUriString();
		
		InterviewEntity interviewEntity = new InterviewEntity();
		if(candidateInterviewModel!=null) {
//			LOG.info("start time in candidate applcaition ---"+candidateInterviewModel.getStartTime());
//			LOG.info("end time in candidate applcaition ---"+candidateInterviewModel.getEndTime());
			interviewEntity.setFirstPanelistEmailId(candidateInterviewModel.getFirstPanelistEmailId());
			interviewEntity.setLocation(candidateInterviewModel.getLocation());
			interviewEntity.setMode(candidateInterviewModel.getMode());
			interviewEntity.setScheduledDate(candidateInterviewModel.getScheduledDate());
			interviewEntity.setSecondPanelistEmailId(candidateInterviewModel.getSecondPanelistEmailId());
			interviewEntity.setTime(candidateInterviewModel.getTime());
			interviewEntity.setStartTime(candidateInterviewModel.getStartTime());
			interviewEntity.setEndTime(candidateInterviewModel.getEndTime());
		}
		
		CandidateModel createCandidateOutputResponse = new CandidateModel();
		CandidateModel candidateInterviewDetails = new CandidateModel();
		Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateInterviewModel.getCandidateId());
		if(!candidateEntity.isPresent()) {
			//LOG.debug("Inside no candidate found");
			createCandidateOutputResponse.setResponseStatus("Invalid Candidate ID. Please enter a valid ID and try again");
			return createCandidateOutputResponse;
		}else {
			//interviewEntity.setCandidateEmail(candidateEntity.get().getCandidateEmail());
			candidateInterviewDetails.setCandidateContact(candidateEntity.get().getCandidateContact());
			candidateInterviewDetails.setCandidateEmail(candidateEntity.get().getCandidateEmail());
			candidateInterviewDetails.setCandidateName(candidateEntity.get().getCandidateName());
			
			interviewEntity.setCandidateModel(candidateInterviewDetails);
			LOG.info("candidate candidate email present  interviewEntity-----"+interviewEntity.getCandidateModel().getCandidateEmail());
		}
		
		ResponseEntity<InterviewEntity> interviewModel = restTemplate.postForEntity(url, interviewEntity, InterviewEntity.class);
		
		if(interviewModel!=null && interviewModel.getStatusCode()==HttpStatus.OK) {
			InterviewEntity interviewEntityResponse = interviewModel.getBody();
			if(interviewEntityResponse!=null) {
				//Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateInterviewModel.getCandidateId());
				if(candidateEntity.isPresent()) {
					CandidateEntity candidateUpdate = candidateEntity.get();
					candidateUpdate.setInterviewId(interviewEntityResponse.getInterviewId());
					CandidateEntity entity = new CandidateEntity();
					entity = candidateRepository.save(candidateUpdate);
					createCandidateOutputResponse.setInterviewId(entity.getInterviewId());
					//LOG.info("indide candidate id present "+entity.getCandidateId());
					LOG.info("indide candidate enail present "+entity.getCandidateEmail());
					createCandidateOutputResponse.setCandidateId(entity.getCandidateId());
					createCandidateOutputResponse.setCandidateEmail(entity.getCandidateEmail());
					return  createCandidateOutputResponse;
				}
			}
		}
		return null;
	}
}
