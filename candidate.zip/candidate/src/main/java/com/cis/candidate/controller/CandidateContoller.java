package com.cis.candidate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cis.candidate.entity.CandidateEntity;
import com.cis.candidate.model.CandidateInterviewModel;
import com.cis.candidate.model.CandidateList;
import com.cis.candidate.model.CandidateModel;
import com.cis.candidate.service.CandidateService;
@CrossOrigin(origins = "*")
@RestController
@EnableAutoConfiguration
@RequestMapping("/cis/candidate")
public class CandidateContoller {

	@Autowired
	CandidateService candidateService;
	
//	@CrossOrigin(origins = "*")
	@RequestMapping(value ="/create-candidate",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public CandidateModel createCandidate(@RequestBody CandidateModel candidateModel) {
		return candidateService.createCandidate(candidateModel);
	}
	
	@RequestMapping(value ="/{id}",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public  CandidateModel createCandidate(@PathVariable("id") String candidateId) {
		return candidateService.getCandidateDetails(candidateId);
	}
	
	@RequestMapping(value ="/update",method = RequestMethod.PUT, consumes= MediaType.APPLICATION_JSON_VALUE)
	public CandidateEntity updateCandidateDetail(@RequestBody CandidateModel candidateModel) {
		return candidateService.updateCandidateDetail(candidateModel);
	}
	
	@RequestMapping(value ="/all",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public CandidateList getAllCandidates() {
		CandidateList candidateList = new CandidateList();
		candidateList.setListOfCandidates(candidateService.getAllCandidates());
		return candidateList;
	}
	
	@RequestMapping(value ="/create-candidate-interview",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public CandidateModel createCandidateInterview(@RequestBody CandidateInterviewModel candidateInterviewModel) {
		return candidateService.createCandidateInterview(candidateInterviewModel);
	}

}
