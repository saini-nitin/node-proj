package com.cis.candidate.mapper;

import com.cis.candidate.entity.CandidateEntity;
import com.cis.candidate.model.CandidateBasicModel;
import com.cis.candidate.model.CandidateModel;

public class Mapper {

	
	public CandidateEntity mapModelToEntity(CandidateModel candidateModel, CandidateEntity candidateEntity) {
		if(candidateModel!=null) {
			candidateEntity.setCandidateId(candidateModel.getCandidateId());
			candidateEntity.setCandidateName(candidateModel.getCandidateName());
			candidateEntity.setPractice(candidateModel.getPractice());
			candidateEntity.setCustomerAC(candidateModel.getCustomerAC());
			candidateEntity.setQuarter(candidateModel.getQuarter());
			candidateEntity.setRecievedDate(candidateModel.getRecievedDate());
			candidateEntity.setNotes(candidateModel.getNotes());
			candidateEntity.setOfferPU(candidateModel.getOfferPU());
			candidateEntity.setDemandId(candidateModel.getDemandId());
			candidateEntity.setLocation(candidateModel.getLocation());
			candidateEntity.setDoj(candidateModel.getDoj());
			candidateEntity.setCandidateContact(candidateModel.getCandidateContact());
			candidateEntity.setStatus(candidateModel.getStatus());
			candidateEntity.setRemark(candidateModel.getRemark());
			candidateEntity.setBackground(candidateModel.getBackground());
			candidateEntity.setWeekEndingDate(candidateModel.getWeekEndingDate());
			candidateEntity.setRecievedMonth(candidateModel.getRecievedMonth());
			candidateEntity.setParentSkillSet(candidateModel.getParentSkillSet());
			candidateEntity.setResponsible(candidateModel.getResponsible());
			candidateEntity.setProfileAge(candidateModel.getProfileAge());
			candidateEntity.setFirstPanelistEmailId(candidateModel.getFirstPanelistEmailId());
			candidateEntity.setSecondPanelistEmailId(candidateModel.getSecondPanelistEmailId());
			candidateEntity.setCandidateEmail(candidateModel.getCandidateEmail());
		}
		return candidateEntity;
	}
	
	
	public CandidateModel mapEntityToModel(CandidateEntity candidateEntity, CandidateModel candidateModel) {
		if(candidateEntity!=null) {
			candidateModel.setCandidateId(candidateEntity.getCandidateId());
			candidateModel.setCandidateName(candidateEntity.getCandidateName());
			candidateModel.setPractice(candidateEntity.getPractice());
			candidateModel.setCustomerAC(candidateEntity.getCustomerAC());
			candidateModel.setQuarter(candidateEntity.getQuarter());
			candidateModel.setRecievedDate(candidateEntity.getRecievedDate());
			candidateModel.setNotes(candidateEntity.getNotes());
			candidateModel.setOfferPU(candidateEntity.getOfferPU());
			candidateModel.setDemandId(candidateEntity.getDemandId());
			candidateModel.setLocation(candidateEntity.getLocation());
			candidateModel.setDoj(candidateEntity.getDoj());
			candidateModel.setCandidateContact(candidateEntity.getCandidateContact());
			candidateModel.setStatus(candidateEntity.getStatus());
			candidateModel.setRemark(candidateEntity.getRemark());
			candidateModel.setBackground(candidateEntity.getBackground());
			candidateModel.setWeekEndingDate(candidateEntity.getWeekEndingDate());
			candidateModel.setRecievedMonth(candidateEntity.getRecievedMonth());
			candidateModel.setParentSkillSet(candidateEntity.getParentSkillSet());
			candidateModel.setResponsible(candidateEntity.getResponsible());
			candidateModel.setProfileAge(candidateEntity.getProfileAge());
			candidateModel.setFirstPanelistEmailId(candidateEntity.getFirstPanelistEmailId());
			candidateModel.setSecondPanelistEmailId(candidateEntity.getSecondPanelistEmailId());
			candidateModel.setCandidateEmail(candidateEntity.getCandidateEmail());
		}
		return candidateModel;
	}
	
	public CandidateBasicModel mapEntityToModelBasic(CandidateEntity candidateEntity, CandidateBasicModel candidateModel) {
		if(candidateEntity!=null) {
			candidateModel.setCandidateId(candidateEntity.getCandidateId());
			candidateModel.setCandidateName(candidateEntity.getCandidateName());
			candidateModel.setCandidateContact(candidateEntity.getCandidateContact());
			candidateModel.setStatus(candidateEntity.getStatus());
			candidateModel.setCandidateEmail(candidateEntity.getCandidateEmail());
		}
		return candidateModel;
	}
	
}
