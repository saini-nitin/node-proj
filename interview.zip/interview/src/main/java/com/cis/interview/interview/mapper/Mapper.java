package com.cis.interview.interview.mapper;

import com.cis.interview.interview.entity.InterviewEntity;
import com.cis.interview.interview.model.InterviewModel;

public class Mapper {

	public InterviewEntity modelToEntity(InterviewModel interviewModel, InterviewEntity interviewEntity) {
		
		if(interviewEntity!=null && interviewModel!=null) {
			interviewEntity.setFirstPanelistEmailId(interviewModel.getFirstPanelistEmailId());
			interviewEntity.setLocation(interviewModel.getLocation());
			interviewEntity.setMode(interviewModel.getMode());
			interviewEntity.setScheduledDate(interviewModel.getScheduledDate());
			interviewEntity.setSecondPanelistEmailId(interviewModel.getSecondPanelistEmailId());
			interviewEntity.setTime(interviewModel.getTime());
		}
		return interviewEntity;
	}
}
