package com.cis.authentication.authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cis.authentication.authentication.model.UserModel;
import com.cis.authentication.authentication.service.AuthenticationService;

@CrossOrigin(origins = "*")
@RestController
@EnableAutoConfiguration
@RequestMapping("/cis/auth")
public class AuthenticateController {

	@Autowired
	AuthenticationService authenticationService;
	
	@RequestMapping(value ="/authenticate-user",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public UserModel authenticateUser(@RequestBody UserModel user) {
		return authenticationService.authenticateUser(user);
	}
}
