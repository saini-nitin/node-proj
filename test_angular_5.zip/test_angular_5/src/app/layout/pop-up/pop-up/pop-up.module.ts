import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PopUpComponent } from '../pop-up.component';
import { PopUpRoutingModule } from '../pop-up-routing/pop-up-routing.module';
import { MaterialTimeControlModule } from '../../clock/material-time-control.module';

@NgModule({
  imports: [
    CommonModule,
    PopUpRoutingModule,
    MaterialTimeControlModule
  ],
  declarations: [PopUpComponent]
})
export class PopUpModule { }
