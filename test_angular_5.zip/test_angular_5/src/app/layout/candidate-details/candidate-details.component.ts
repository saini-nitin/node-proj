import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CandidateService } from '../services/candidate.service';
import { BlockUI,NgBlockUI } from 'ng-block-ui';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Subject } from 'rxjs/Subject';
import { FormControl, FormGroup , Validators} from '@angular/forms';
import { routerTransition } from '../../router.animations';
import { Candidate } from '../candidate/model/Candidate';

@Component({
  selector: 'app-candidate-details',
  templateUrl: './candidate-details.component.html',
  styleUrls: ['./candidate-details.component.scss'],
  animations: [routerTransition()]
})
export class CandidateDetailsComponent implements OnInit,OnDestroy {
  @BlockUI() blockUI: NgBlockUI; 
  componentDestroyed: Subject<boolean> = new Subject();
  readOnly = false;
  id: number;
  candidateIdValue:string;
  private sub: any;
  currentStatusDropDown : any;
  constructor(
    private route: ActivatedRoute,
    private candidateService: CandidateService,
    private _flashMessagesService : FlashMessagesService  
  ) { }

  dropDown:any;
  ngOnInit() {  
        this.toggleEdit();
        this.sub = this.route.params.subscribe(params => {
            this.id = params['id']; // (+) converts string 'id' to a number
        });
        this.getCurrentStatusDropdown()
        this.getCandidate();

  }

  copyOfCandidateDetails = new Candidate();  
  candidateDetails =  new Candidate();
  getCandidate(): void{
    this.blockUI.start();  
   
    this.sub = this.candidateService.getCandidateDetails(this.id).subscribe(
      data => {   
        //console.log('this.dataSource',data);
        this.candidateDetails = data;
        this.blockUI.stop();
        console.log('this.candidateDetails',this.candidateDetails);
        this.setFormsData(this.candidateDetails);   
        this.candidateIdValue = this.candidateDetails.candidateId;   
        
        this.copyOfCandidateDetails = this.candidateDetails;
        
      },
      err => {
        //console.log('this.dataSource',err);        
        this.blockUI.stop();        
        this._flashMessagesService.show('Server Error. Please try after sometime.', { cssClass: 'alert-danger', timeout: 10000 });  
      },
      
    );
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
    this.componentDestroyed.next(true);
    this.componentDestroyed.complete();
  }

  formValidationMessages = {
    'candidateId': [
      { type: 'required', message: 'Candidate ID is required' }
    ],
    'candidateName': [
      { type: 'required', message: 'Candidate name is required' }
    ],
    'practice': [
      { type: 'required', message: 'Practice is required' }
    ],
    'customerAC': [
      { type: 'required', message: 'Customer Account is required' },
      { type: 'date', message: 'Enter a valid date' }
    ],
    'quarter': [
      { type: 'required', message: 'Quarter is required' }
    ],
    'recievedDate': [
      { type: 'required', message: 'Recieved Date is required' }
    ],
    'notes': [
      { type: 'required', message: 'Notes is required' }
    ],

    'offerPU': [
      { type: 'required', message: 'Offered Posted Unit is required' }
    ],
    'demandId': [
      { type: 'required', message: 'Demand ID is required' }
    ],
    'location': [
      { type: 'required', message: 'Location is required' }
    ],
    'doj': [
      { type: 'required', message: 'Date of joining is required' }
    ],
    'candidateContact': [
      { type: 'required', message: 'Candidate\'s Contact is required' }
    ],
    'status': [
      { type: 'required', message: 'Status is required' }
    ],
    'firstPanelistEmailId': [
      { type: 'required', message: 'Panelist Email ID is required' },
      { type: 'email', message: 'Enter a valid email' }      
    ],
    'secondPanelistEmailId': [
      { type: 'required', message: 'Panelist Email ID is required' },
      { type: 'email', message: 'Enter a valid email' }            
    ],
    'remark': [
      { type: 'required', message: 'Remark is required' }
    ],
    'background': [
      { type: 'required', message: 'Background is required' }
    ],
    'weekEndingDate': [
      { type: 'required', message: 'Week ending date is required' }
    ],
    'recievedMonth': [
      { type: 'required', message: 'Recieved Month is required' }
    ],
    'parentSkillSet': [
      { type: 'required', message: 'Parent Skill set is required' }
    ],
    'responsible': [
      { type: 'required', message: 'Responsible person is required' }
    ],
    'profileAge': [
      { type: 'required', message: 'Profile Age is required' }
    ],
    'candidateEmail': [
      { type: 'required', message: 'Candidate Email ID is required' }
    ]
  }

  // form = new FormGroup({
  //   first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),
  //   last: new FormControl('Drew', Validators.required)
  // });

  createCandidateForm = new FormGroup({
    candidateId: new FormControl('', Validators.compose([
    Validators.required
    ])),
    candidateName: new FormControl('', Validators.compose([
      Validators.required
    ])),
    practice: new FormControl('', Validators.compose([
        Validators.required
    ])),
    customerAC: new FormControl('', Validators.compose([
      Validators.required
    ])),
    quarter: new FormControl('', Validators.compose([
      Validators.required
    ])),
    recievedDate: new FormControl({value:''}, Validators.compose([
      Validators.required
    ])),
    notes: new FormControl('', Validators.compose([
      Validators.required
    ])),
    offerPU: new FormControl('', Validators.compose([
      Validators.required
    ])),
    demandId: new FormControl('', Validators.compose([
      Validators.required
    ])),
    location: new FormControl('', Validators.compose([
      Validators.required
    ])),
    doj: new FormControl('', Validators.compose([
      Validators.required
    ])),


    candidateContact: new FormControl('', Validators.compose([
      Validators.required
    ])),
    status: new FormControl('', Validators.compose([
      Validators.required
    ])),
    firstPanelistEmailId: new FormControl('', Validators.compose([
      Validators.required,
      Validators.email
    ])),
    secondPanelistEmailId: new FormControl('', Validators.compose([
      Validators.required,
      Validators.email
    ])),
    candidateEmail: new FormControl('', Validators.compose([
      Validators.required,
      Validators.email
    ])),
    remark: new FormControl('', Validators.compose([
      Validators.required
    ])),

    background: new FormControl('', Validators.compose([
      Validators.required
    ])),
    weekEndingDate: new FormControl('', Validators.compose([
      Validators.required
    ])),
    recievedMonth: new FormControl('', Validators.compose([
      Validators.required
    ])),
    parentSkillSet: new FormControl('', Validators.compose([
      Validators.required
    ])),
    responsible: new FormControl('', Validators.compose([
      Validators.required
    ])),
    profileAge: new FormControl('', Validators.compose([
      Validators.required
    ])),
    interviewId: new FormControl('', Validators.compose([
     
    ])),
    responseStatus: new FormControl('', Validators.compose([
      
    ]))
  })

  setFormsData(candidateDetails) {
    this.createCandidateForm.setValue(candidateDetails);
  }

  toggleEdit(){
    this.readOnly = !this.readOnly;
    const state = this.readOnly ? 'disable' : 'enable';
    this.toggleControl(state);
    // Object.keys(this.createCandidateForm.controls).forEach((controlName) => {
    //     if(controlName!='candidateId'){
    //         this.createCandidateForm.controls[controlName][state](); // disables/enables each form control based on 'this.formDisabled'
    //     }else{
    //       this.createCandidateForm.controls[controlName]['disable'](); // disables/enables each form control based on 'this.formDisabled'
    //     }
    // }); 
    //this.createCandidateForm.controls["candidateId"]['disable'](); // disables/enables each form control based on 'this.formDisabled'
    
  }

  getCurrentStatusDropdown() :any {
    //console.log('candidate object',this.candidate);
    this.candidateService.getCandidatesCurrentStatusValues();
    this.sub = this.candidateService.getCandidatesCurrentStatusValues().subscribe(
      data => {
        this.currentStatusDropDown=data;
        //console.log('this.dataSource',data);
        //console.log('this.candidateDetails123',this.candidateDetails);
        this.blockUI.stop();          
        //this.currentStatusDropDown;     
        //this.candidateDetails.currentStatusDropDown = {}; 
        //this.candidateDetails.currentStatusDropDown = this.currentStatusDropDown;
        //console.log('this.candidateDetails123',this.candidateDetails);
      },
      err =>{
        this.blockUI.stop();  
        this.serverErrorFunction('Server Error. Please try after sometime.');
      }
    );  
  }

  serverErrorFunction(err) :void{
    this._flashMessagesService.show(err, { cssClass: 'alert-danger', timeout: 10000 }); 
  }

  updateCandidateDetails(candidateDetails):void{
      this.blockUI.start();
      if(candidateDetails!=null){
        candidateDetails.candidateId = this.candidateIdValue
      }     
      this.sub = this.candidateService.updateCandidateDetails(candidateDetails).subscribe(
        data =>{
            this.toggleEdit();
            if(data!=null && data.responseStatus==null){
              window.scroll(0,0);
              this._flashMessagesService.show("Candiadte Details updated successfully", { cssClass: 'alert-success', timeout: 10000 });               
            }
            this.blockUI.stop();
        },
        err =>{
          this.serverErrorFunction('Server Error. Please try after sometime.');
          window.scroll(0,0);
          this.blockUI.stop();
        }
      )
  }

  cancel():void{
    this.readOnly = !this.readOnly;
    const state = this.readOnly ? 'disable' : 'enable';
    //this.candidateDetails = JSON.parse(JSON.stringify(this.copyOfCandidateDetails));
    //this.copyOfCandidateDetails.candidateId=this.candidateIdValue;
    //console.log('this.copyOfCandidateDetails',this.copyOfCandidateDetails);
    this.setFormsData(this.copyOfCandidateDetails); 
    this.toggleControl(state); 
  }

  toggleControl(state){
    Object.keys(this.createCandidateForm.controls).forEach((controlName) => {
      if(controlName!='candidateId'){
          this.createCandidateForm.controls[controlName][state](); // disables/enables each form control based on 'this.formDisabled'
      }else{
        this.createCandidateForm.controls[controlName]['disable'](); // disables/enables each form control based on 'this.formDisabled'
      }
  }); 
  }

}
